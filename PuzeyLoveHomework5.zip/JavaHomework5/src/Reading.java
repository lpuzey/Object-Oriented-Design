import java.util.LinkedList;

public class Reading {

	Time tim;
	double temp;
//	LinkedList<Double> tempKeeper;
	double rainFall;
//	LinkedList<Double> rainKeeper;
	
	Reading(Time tim, double temp, double rainFall){
		this.tim = tim;
		this.temp = temp;
		this.rainFall = rainFall;
//		tempKeeper.add(temp);
//		rainKeeper.add(rainFall);
	}
	
}
