/**
 * This class deals with episodes
 * @author Linda Puzey, Sarah Love
 */

class Episode 
{
	String epTitle;
	double runTime;

	Episode(String epTitle, double runTime)
	{
		this.epTitle = epTitle;
		this.runTime = runTime;
	}
	
}

