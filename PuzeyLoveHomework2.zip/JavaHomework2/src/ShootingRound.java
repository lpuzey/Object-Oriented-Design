
public class ShootingRound {

	int numTargets; //number of targets hit out of 5
	Boolean form;//prone = false, standing = true
	
	ShootingRound(int numTargets,Boolean form){
		this.numTargets = numTargets;
		this.form = form;
	}
}
