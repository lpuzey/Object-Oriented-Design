
public interface IEvent {

	public double pointsEarned();
}
