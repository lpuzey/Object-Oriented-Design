
public class ShootingRound {

	int numTargets; //number of targets hit out of 5
	
	ShootingRound(int numTargets){
		this.numTargets = numTargets;
	}
}
